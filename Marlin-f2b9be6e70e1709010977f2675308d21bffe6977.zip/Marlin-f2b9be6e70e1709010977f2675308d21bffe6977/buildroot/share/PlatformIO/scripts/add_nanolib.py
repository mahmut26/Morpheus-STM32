Import("env")
env.Append(LINKFLAGS=["--specs=nano.specs"])
